package com.example.weight_tracking_app;

import android.app.Application;
import androidx.appcompat.app.AppCompatDelegate;

public class WeightTrackerApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
    }
}
